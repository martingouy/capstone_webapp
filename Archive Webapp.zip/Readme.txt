***********************************
		README
***********************************

Web Framework: Bottle (http://bottlepy.org/docs/dev/index.html)

Command to Run webapp locally: python webapp.py run

Dependencies: 
- Doc2Vec by gensim

This version of the webapp is only an alpha version working on a small subset of the full database with limited functionalities.
The Doc2Vec model has been pretrained and is loaded when the webapp is launched
You can play with this demo by inputting some patent ids belonging to the invalisation database (dataset folder) and look at the position of the invalidated patent
