$(function(){ 
	$('#results').hide();
	$('.submit').click(function(){
		$('#results').hide();
		var link = "patent/" + $('#id_patent').val();
		$.getJSON( link, function( data ) {
			console.log(data[0]);
			var dynatable = $('#my-final-table').dynatable({
			  dataset: {
			    records: data
			  }
			}).data('dynatable');
			dynatable.settings.dataset.originalRecords = data;
            dynatable.process();
			$('#results').show();
			$('a.zoombox').zoombox({width:1000, height:800});
		});
	});

});