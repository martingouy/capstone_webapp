import gensim
import numpy as np
import random
import gensim.models.doc2vec
import multiprocessing
import json

from gensim import utils
from gensim.models import Doc2Vec
from gensim.models.doc2vec import LabeledSentence
from nltk.tokenize import RegexpTokenizer

import matplotlib.pyplot as plt

# Initial Configuration
DB_FILE = "dataset/shuffled_training.txt"
INVALIDATION_FILE = "dataset/train_invalidation.txt"
patent_id_mapping = { }

class LabeledSentences:
    def __init__(self, source, id_dict, id_dict_reverse):
        self.source = source
        self.id_dict = id_dict
        self.id_dict_reverse = id_dict_reverse

    def build_mapping(self):
        with utils.smart_open(self.source) as fin:
            for index, line in enumerate(fin):
                pid, tokens = parse_line(line)
                #if pid not in self.id_dict: 
                self.id_dict[pid] = index
                self.id_dict_reverse[str(index)] = pid

    def __iter__(self):
        with utils.smart_open(self.source) as fin:
            for index, line in enumerate(fin):
                pid, tokens = parse_line(line)
                yield LabeledSentence(words = tokens, tags = ['VEC_%s' % index])

def parse_line(line, SEP = "||"):
    decoded = utils.to_unicode(line)
    index = decoded.find(SEP)
    return decoded[:index], decoded[index+1:].split()

def evaluate_model(model, id_dict, N, test = INVALIDATION_FILE):
    scores, pairs = [], []
    for pair in open(INVALIDATION_FILE, "r"):
        try:
            p1, p2 = pair.split()
            if p1 == p2: continue
            i1, i2 = id_dict[p1], id_dict[p2]
            scores.append([val[0] for val in model.docvecs.most_similar('VEC_%s' % i2, topn = N)].index('VEC_%s' % i1))
            pairs.append(i1, i2)
            count += 1
        except:
            pass
    return scores, pairs

# Extract dataset into LabeledSentences
def gen_sentences(id_dict = {}, id_dict_reverse = {}):
    sentences = LabeledSentences(DB_FILE, id_dict, id_dict_reverse)
    sentences.build_mapping()
    return sentences, id_dict, id_dict_reverse

# Train Doc2Vec model on sentences
def train_model(sentences, feat_size = 100, iterations = 10):
    cores = multiprocessing.cpu_count()
    assert gensim.models.doc2vec.FAST_VERSION > -1, "this will be painfully slow otherwise"

    model = Doc2Vec(dm = 1, dm_concat = 0, min_count = 1, window = 10, size = feat_size, sample = 1e-4, negative = 5, workers = cores, alpha = 0.025, min_alpha = 0.025)
    model.build_vocab(sentences)

    # Train the model, decrease learning rate for better results
    for epoch in range(iterations):
        model.train(sentences)
        model.alpha -= 0.002
        model.min_alpha = model.alpha
        print('Done %d' % epoch)

    return model

def build_graph(sentences, id_dict, N = 4988, features = [10, 20, 50, 100, 200]):
    median_scores, mean_scores = [], []
    for feat in features:
        model = train_model(sentences, feat_size = feat)
        t_scores, _ = evaluate_model(model, id_dict, N)
        median_scores.append(np.median(t_scores))
        mean_scores.append(np.mean(t_scores))

    # Print Median vs. Feature Size
    plt.plot(features, median_scores)
    plt.title('Feature Size vs. Median Ranking of Invalidating Patents')
    plt.xlabel('Feature Size')
    plt.ylabel('Median Ranking of Invalidating Patents')
    plt.savefig("median_perforance")

    # Print Mean vs. Feature Size
    plt.plot(features, mean_scores)
    plt.title('Feature Size vs. Median Ranking of Invalidating Patents')
    plt.xlabel('Feature Size')
    plt.ylabel('Mean Ranking of Invalidating Patents')
    plt.savefig("mean_performance")


def get_most_similar(model, patent_id, patent_id_mapping, patent_id_mapping_rev):
    patent_id = patent_id
    patent_id_2 = patent_id_mapping[patent_id]
    most_sim = model.docvecs.most_similar('VEC_%s' % patent_id_2, topn = 10)

    # remap the most_sim dictionary to use patent ids instead
    most_sim = [(str(patent_id_mapping_rev[key[4:]]), value) for key, value in most_sim]
    return(most_sim)

model = Doc2Vec.load("model.d2v")
sentences, patent_id_mapping, patent_id_mapping_rev = gen_sentences()

#get_most_similar(model, '4882269', patent_id_mapping, patent_id_mapping_rev)
#build_graph(sentences, patent_id_mapping)

    