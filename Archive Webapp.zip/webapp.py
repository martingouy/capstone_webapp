from bottle import run, template, static_file, view, Bottle, request
from backend import generate_json
import json

app = Bottle()

@app.route('/')
@view('index')
def index():
    return { 'get_url':  app.get_url } 


@app.route('/patent/<id_patent>')
def get_json(id_patent):
    return json.dumps(generate_json(id_patent))


@app.route('/static/:path#.+#', name='static')
def static(path):
	return static_file(path, root='static')

app.run(host='localhost', port=8080, debug=True)

