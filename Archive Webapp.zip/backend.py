import doc_vec
import json
from gensim.models import Doc2Vec
from bs4 import BeautifulSoup as bs
import requests
import sqlite3

model = Doc2Vec.load("model.d2v")
sentences, patent_id_mapping, patent_id_mapping_rev = doc_vec.gen_sentences()

def get_title(patent_id):
	conn = sqlite3.connect('patents.sqlite')
	c = conn.cursor()
	query = "SELECT title FROM patents WHERE id = '" + str(patent_id) + "'"
	for row in c.execute(query):
		return row[0]

def get_title_patent(id_patent):
	url = "http://www.google.com/patents/US" + str(id_patent)

	r = requests.get(url)
	content = r.text.encode('utf-8')

	soup = bs(content)
	title = soup.find("invention-title").get_text().encode('utf-8').lower()

	return title

def generate_json(id_patent):
	most_sim = doc_vec.get_most_similar(model, id_patent, patent_id_mapping, patent_id_mapping_rev)

	output = [{"id" : id_patent, "title": '<a class = "zoombox" href = http://www.google.com/patents/US{}>{}</a>'.format(id_patent, get_title(id_patent)), "score": int(score * 100)} for id_patent, score in most_sim]

	return output

